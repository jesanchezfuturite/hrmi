    <footer>
      <div class="row">
        <div class="large-4 medium-4 small-12 columns">
          <h3>Contáctanos</h3>
          <p><i class="flaticon-placeholder"></i>Avenida San Rafael No. 450,<br> San Rafael, Guadalupe, N.L.</p>
          <p><i class="flaticon-envelope"></i> <a href="" target="_blank">info@patronatohrmi.com</a></p>
          <p><i class="flaticon-technology"></i> +52 (81) 81313232 Ext. 50344</p>
        </div>
        <div class="large-3 medium-3 small-12 columns">
          <h3>Síguenos</h3>
          Mantente al tanto de todo lo que sucede
            <div class="row">
              <div class="large-12 columns">
                <div class="row collapse">
                  <div class="small-10 columns">
                    <input type="text" placeholder="correo electrónico">
                  </div>
                  <div class="small-2 columns">
                    <a href="#" class="button postfix secondary b-mail"><i class="flaticon-envelope"></i></a>
                  </div>
                </div>
              </div>
            </div>
           <!-- <ul class="redes top10">
            <li><a href="" target="_blank"><i class="flaticon-facebook-letter-logo"></i></a></li>
            <li><a href="" target="_blank"><i class="flaticon-twitter-logo-silhouette"></i></a></li>
            <li><a href="" target="_blank"><i class="flaticon-youtube"></i></a></li>
            <li><a href="" target="_blank"><i class="flaticon-instagram-photo-camera-logo-outline"></i></a></li>
          </ul> -->
        </div>
        <div class="large-4 medium-4 small-12 columns">
          <h6>Certificaciones <br>y Reconocimientos</h6>
          <ul class="text7">
            <li>Certificación del Consejo de Salubridad General</li>
            <li>Acreditación de Hospital Seguro</li>
            <li>Acreditación para atender Malformaciones Congénitas</li>
            <li>Acreditación para realizar Implantes Cocleares</li>
            <li>Acreditación del Seguro Popular Causes</li>
          </ul>
        </div>
        <div class="clear top20"></div>
        <hr>
        <div class="large-6 columns text7">
          &copy; 2017, Patronato Hospital Materno Infantil. Todos los derechos reservados.
        </div>
        <div class="large-6 columns text-right text7">
         <a href="">Políticas de Privacidad </a> | <a href=""> Aviso legal</a>
        </div>
        
      </div>
    </footer>