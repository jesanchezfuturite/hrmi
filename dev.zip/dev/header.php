<header>
    <div class="contain-to-grid sticky">
      <nav class="top-bar" data-topbar role="navigation">
        <ul class="title-area">
          <li class="name">
            <a class="logo-header" href="index.php"><img src="../img/logo.jpg" alt=""></a>
          </li>
          <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
        </ul>
        <section class="top-bar-section">
          <ul class="menu--float">
            <li><a href="nosotros.php">Patronato</a></li>
            <!-- <li><a href="nosotros.php">Nosotros</a></li> -->
            <li><a href="logros.php">Logros</a></li>
            <li><a href="voluntariado.php">Voluntariado</a></li>
            <!-- <li><a href="galeria.php">Galería</a></li> -->
            <li><a href="contacto.php">Contacto</a></li>
            <li><a href="">Informes</a></li>
            <li class="active"><a href="donar.php">DONAR</a></li>
          </ul>
        </section>
      </nav>
    </div>
</header>