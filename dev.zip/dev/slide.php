        <div class="slider">  
            <ul class="bxslider" >
              <li><img src="img/s3.jpg" alt="Patronato Hospital Materno Infantil"/>
                <div class="slider-text text-left sldr-1">
                  <span>Pasión</span>
                </div>
              </li>   
              <li><img src="img/s2.jpg" alt="Patronato Hospital Materno Infantil"/>
                <div class="slider-text text-left sldr-1">
                  <span>Profesionalismo</span>
                </div>
              </li>
              <li><img src="img/s4.jpg" alt="Patronato Hospital Materno Infantil"/>
                <div class="slider-text text-left sldr-1">
                  <span>Equipamiento</span>
                </div>
              </li>
               <li><img src="img/s1.jpg" alt="Patronato Hospital Materno Infantil"/>
                <div class="slider-text text-left sldr-1">
                  <span>Valor humano</span>
                </div>
              </li>                
            </ul>
          </div>